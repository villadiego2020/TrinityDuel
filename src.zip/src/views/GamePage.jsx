import { useState, useEffect } from 'react';
import { generateDeck } from '../utils/gameLogic';
import Card from '../components/Game/Card';
import BattleArena from '../components/Game/BattleArena';
import { motion, AnimatePresence } from 'framer-motion';

export default function GamePage({ onFinishSetup }) {
  const [hand, setHand] = useState([]); 
  const [orderedDeck, setOrderedDeck] = useState([]); 
  const [isBattleMode, setIsBattleMode] = useState(false);

  useEffect(() => {
    setHand(generateDeck());
  }, []);

  const selectCard = (card) => {
    if (orderedDeck.length >= 10) return;
    setOrderedDeck([...orderedDeck, card]);
    setHand(hand.filter(c => c.instanceId !== card.instanceId));
  };

  const undoCard = (card) => {
    setHand([...hand, card]);
    setOrderedDeck(orderedDeck.filter(c => c.instanceId !== card.instanceId));
  };

  if (isBattleMode) {
    return <BattleArena playerDeck={orderedDeck} onFinishGame={onFinishSetup} />;
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#020617] text-white p-4 overflow-hidden w-full">
      
      {/* ส่วนหัว - จัดกลางด้วย items-center */}
      <div className="w-full max-w-6xl flex justify-between items-center mb-8 border-b border-white/10 pb-4">
        <h2 className="text-2xl font-black italic tracking-tighter text-cyan-400 uppercase">Trinity Duel</h2>
        <div className="text-xl font-bold font-mono text-yellow-500">{orderedDeck.length} / 10</div>
      </div>

      {/* 1. DECK SLOT SECTION - บังคับแถวละ 10 (Flex-row) */}
      <div className="w-full max-w-6xl bg-slate-900/40 p-6 rounded-3xl border border-white/5 backdrop-blur-xl mb-12 shadow-2xl">
        <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mb-6 text-center">Tactical Deployment Queue</p>
        
        {/* บังคับเรียงแนวนอน 10 ใบ และจัดกึ่งกลางด้วย justify-center */}
        <div className="flex flex-row justify-center items-center gap-2 w-full">
          {Array.from({ length: 10 }).map((_, index) => (
            <div key={index} className="flex flex-col items-center gap-2 flex-shrink-0">
              <div className={`w-[70px] h-[120px] rounded-lg border-2 border-dashed flex items-center justify-center transition-all
                ${orderedDeck[index] ? 'border-transparent shadow-[0_0_15px_rgba(34,211,238,0.3)]' : 'border-slate-800 bg-black/20'}
              `}>
                {orderedDeck[index] ? (
                  <Card type={orderedDeck[index].id} onClick={() => undoCard(orderedDeck[index])} />
                ) : (
                  <span className="text-[10px] text-slate-700 font-bold italic">{index + 1}</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. CARD SELECTION SECTION (Hand) - บังคับแถวละ 10 เช่นกัน */}
      <div className="w-full max-w-6xl bg-black/30 p-8 rounded-[2.5rem] border border-white/10 shadow-inner backdrop-blur-md">
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] mb-6 text-center">Select Your Units</p>
        
        {/* บังคับเรียงแนวนอน 10 ใบ และจัดกึ่งกลาง */}
        <div className="flex flex-row flex-wrap justify-center items-center gap-3 w-full">
          <AnimatePresence>
            {hand.map((card) => (
              <motion.div 
                key={card.instanceId} 
                layout 
                initial={{ scale: 0, opacity: 0 }} 
                animate={{ scale: 1, opacity: 1 }} 
                exit={{ scale: 0, opacity: 0 }}
                className="flex-shrink-0"
              >
                <Card type={card.id} onClick={() => selectCard(card)} />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* ปุ่มเริ่มเกม - จัดกึ่งกลางจอ */}
      <AnimatePresence>
        {orderedDeck.length === 10 && (
          <motion.button 
            initial={{ y: 100 }} animate={{ y: 0 }}
            onClick={() => setIsBattleMode(true)}
            className="fixed bottom-10 left-1/2 -translate-x-1/2 px-16 py-4 bg-cyan-600 hover:bg-cyan-500 text-white rounded-full text-xl font-black uppercase italic shadow-[0_0_30px_rgba(8,145,178,0.5)] z-50 border border-cyan-400 transition-all active:scale-95"
          >
            Initiate Duel
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}